document.addEventListener(
  "DOMContentLoaded",
  () => {
    console.log("lesson-crud-populate-starter JS imported successfully!");
  },
  false
);
